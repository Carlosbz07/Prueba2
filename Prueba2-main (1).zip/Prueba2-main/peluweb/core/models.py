from django.db import models


# Create your models here.



class Usuario(models.Model):
    Nombre = models.CharField(max_length=50)
    Apellido = models.CharField(max_length=50)
    Correo_Electronico = models.CharField(max_length=50)
    Sexo = models.CharField(max_length=50)    
    Rut = models.IntegerField()
    sinopsis = models.TextField(null=True, blank=True)
    imagen = models.ImageField(null=True, blank=True)
    

    def __str__(self):
        return self.Nombre

class Reserva(models.Model):
    Horario = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    

    


    